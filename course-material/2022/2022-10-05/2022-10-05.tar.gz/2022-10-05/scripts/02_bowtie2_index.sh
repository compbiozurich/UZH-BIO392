#!/bin/env/bash
set -euo pipefail

#Before we can align the reads to the reference with bowtie2, we need to build
#bowtie2 indices for reference sequence.
bowtie2-build \
../data/reference/APC.fa \
../data/reference/APC_idx
