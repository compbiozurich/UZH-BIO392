#!/bin/env/bash
set -euo pipefail

# We run the GangSTR STR genotyping tool on both our alignments (wildtype and  mutated)
# GangSTR also needs the reference genome and a tab-separated file indicating where STR loci are located
# in the reference genome.
GangSTR --bam ../data/alignments/mutated/APC_mut.bam \
--ref ../data/reference/APC.fa \
--regions ../data/repeats/APC_repeats.tsv \
--out ../results/mutated/mutated

GangSTR --bam ../data/alignments/wildtype/APC_wt.bam \
--ref ../data/reference/APC.fa \
--regions ../data/repeats/APC_repeats.tsv \
--out ../results/wildtype/wildtype
