#!/bin/env/bash
set -euo pipefail

# Perform the alignment for the wild type reads against the reference sequence
bowtie2 \
-x ../data/reference/APC_idx \
-1 ../data/reads/wildtype/APC_wt_out1.fq -2 ../data/reads/wildtype/APC_wt_out2.fq \
-S ../data/alignments/wildtype/APC_wt.sam \

# Add read group information to the generated alignment (needed by GangSTR later on)
samtools addreplacerg -r ID:sim20220921 -r PL:wgsim -r SM:wt ../data/alignments/wildtype/APC_wt.sam > tmp.sam
mv tmp.sam ../data/alignments/wildtype/APC_wt.sam

# Perform the alignment for the mutated reads against the reference sequence
bowtie2 \
-x ../data/reference/APC_idx \
-1 ../data/reads/mutated/APC_mut_out1.fq -2 ../data/reads/mutated/APC_mut_out2.fq \
-S ../data/alignments/mutated/APC_mut.sam \

# Add read group information to the generated alignment (needed by GangSTR later on)
samtools addreplacerg -r ID:sim20220921 -r PL:wgsim -r SM:wt ../data/alignments/mutated/APC_mut.sam > tmp.sam
mv tmp.sam ../data/alignments/mutated/APC_mut.sam
