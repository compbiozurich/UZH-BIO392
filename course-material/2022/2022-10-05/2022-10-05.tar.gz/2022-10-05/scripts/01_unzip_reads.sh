#!/bin/env/bash
set -euo pipefail

#The fastq files are compressed to save space, the following commands will unzip them
gunzip ../data/reads/wildtype/*.fq.gz
gunzip ../data/reads/mutated/*.fq.gz
